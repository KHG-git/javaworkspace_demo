package com.sk.eadmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EadminApplication {

	public static void main(String[] args) {
		SpringApplication.run(EadminApplication.class, args);
	}

}
