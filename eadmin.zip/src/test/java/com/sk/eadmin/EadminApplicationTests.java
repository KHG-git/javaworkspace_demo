package com.sk.eadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EadminApplicationTests {

	@Test
	void contextLoads() {
	}

}
